﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class user : System.Web.UI.Page
{
    string strSql;
    SqlConnection sqlCon = new SqlConnection();
    SqlCommand sqlCmd = new SqlCommand();
    SqlDataReader sqlReader;

    protected void Page_Load(object sender, EventArgs e)
    {
        string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        string userID = null;
        HttpCookie cook = Request.Cookies["UserInfo"];
        if (cook != null)
        {
            userID = cook.Values["UserID"];
            sqlCon = new SqlConnection(strConn);
            sqlCon.Open();
            strSql = "select user_name from [user] where user_id = '" + userID + "'";
            sqlCmd = new SqlCommand(strSql, sqlCon);
            sqlReader = sqlCmd.ExecuteReader();
            if (sqlReader.Read())
            {
                Label5.Text = sqlReader["user_name"].ToString();
            }
            else
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：無法連結資料庫')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }

            sqlCon.Close();
            sqlCmd.Cancel();
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('錯誤：您尚未登入')</script><br>";
            this.Page.Controls.Add(myMsg1);
            Response.Redirect("/login.aspx");
        }



        sqlCon = new SqlConnection(strConn);
        sqlCon.Open();
        strSql = "SELECT COUNT(user_id) as Num FROM [user] ";
        sqlCmd = new SqlCommand(strSql, sqlCon);
        sqlReader = sqlCmd.ExecuteReader();
        if (sqlReader.Read())
        {
            Label1.Text = sqlReader["Num"].ToString();
            //Response.Write(sqlReader["user_login"].ToString());
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('錯誤：帳號數量抓取錯誤')</script><br>";
            this.Page.Controls.Add(myMsg1);
        }

        sqlCon.Close();
        sqlCmd.Cancel();
        sqlCon.Open();

        strSql = "SELECT COUNT(user_id) as Num FROM [user]";
        sqlCmd = new SqlCommand(strSql, sqlCon);
        sqlReader = sqlCmd.ExecuteReader();
        if (sqlReader.Read())
        {
            Label2.Text = sqlReader["Num"].ToString();
            //Response.Write(sqlReader["user_login"].ToString());
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('錯誤：帳號數量抓取錯誤')</script><br>";
            this.Page.Controls.Add(myMsg1);
        }

        sqlCon.Close();
        sqlCmd.Cancel();


        //this.GridView1.DataSource = SqlDataSource1;
        //this.GridView1.DataBind();
        Panel2.Visible = false;
        Panel1.Visible = true;
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (int.Parse(DropDownList1.SelectedValue) == 1)
        {
            int count = 0;
            int[] delete;
            if ((Panel1.Visible == true) && (Panel2.Visible == false))
            {
                delete = new int[GridView1.Rows.Count];
                for (int i = 0; i < this.GridView1.Rows.Count; i++)
                {
                    CheckBox cb = (CheckBox)this.GridView1.Rows[i].FindControl("CheckBox3");
                    if (cb.Checked == true)
                    {
                        delete[count] = int.Parse(GridView1.Rows[i].Cells[0].Text);
                        count++;
                    }
                }
            }
            else if ((Panel1.Visible == false) && (Panel2.Visible == true))
            {
                delete = new int[GridView2.Rows.Count];
                for (int i = 0; i < this.GridView2.Rows.Count; i++)
                {
                    
                    CheckBox cb = (CheckBox)this.GridView2.Rows[i].FindControl("CheckBox4");
                    if (cb.Checked == true)
                    {
                        delete[count] = int.Parse(GridView2.Rows[i].Cells[0].Text);
                        count++;
                    }
                }
            }
            else
            {
                delete = new int[GridView1.Rows.Count];
            }
            
            for (int i = 0; i < count; i++)
            {
                
                string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

                sqlCon = new SqlConnection(strConn);
                sqlCon.Open();
                strSql = "delete  from [user] where user_id = '" + delete[i] + "'";
               // Response.Write(delete[i]);

                sqlCmd = new SqlCommand(strSql, sqlCon);
                if (sqlCmd.ExecuteNonQuery() == 1)
                {
                    Literal myMsg1 = new Literal();
                    myMsg1.Text = "<script>alert('成功刪除帳號')</script><br>";
                    this.Page.Controls.Add(myMsg1);
                }else
                {
                    Literal myMsg1 = new Literal();
                    myMsg1.Text = "<script>alert('刪除帳號失敗')</script><br>";
                    this.Page.Controls.Add(myMsg1);
                }

                sqlCon.Close();
                sqlCmd.Cancel();
            }
            GridView1.DataBind();
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('請選擇功能')</script><br>";
            this.Page.Controls.Add(myMsg1);
        }

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string search = TextBox1.Text;
        if (search != "")
        {
            GridView1.Visible = true;
            string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            sqlCon = new SqlConnection(strConn);
            sqlCon.Open();
            strSql = "select * from posts where post_author Like '%" + search + "%'  OR post_title Like '%" + search + "%'   OR post_content Like '%" + search + "%'   OR post_date Like '%" + search + "%'   OR post_modified Like '%" + search + "%'  ORDER BY post_id";
            sqlCmd = new SqlCommand(strSql, sqlCon);

            sqlCmd.Parameters.Add(new SqlParameter("post_title", search));
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(sqlCmd);
            sda.Fill(dt);
            Panel2.Visible = true;
            Panel1.Visible = false;
            this.GridView2.DataSource = dt;
            this.GridView2.DataBind();
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('請輸入搜尋內容')</script><br>";
            this.Page.Controls.Add(myMsg1);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }
        sqlCon.Close();
        sqlCmd.Cancel();
    }

    protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }

    protected void Button5_Click(object sender, EventArgs e)
    {

    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button6_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        Panel1.Visible = false;
        GridView2.DataBind();
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");

    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        HttpCookie cook = Request.Cookies["UserInfo"];
        cook.Expires = DateTime.Now.AddDays(-1d);//設定cookie的到期日為已過期　
        Response.Cookies.Add(cook);//將cookie變動寫回client端
        Response.Redirect("/login.aspx");
    }

    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("/index.aspx");

    }
}