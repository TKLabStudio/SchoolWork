﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class index : System.Web.UI.Page
{
    string strSql;
    SqlConnection sqlCon = new SqlConnection();
    SqlCommand sqlCmd = new SqlCommand();
    SqlDataReader sqlReader;
    bool login = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        string userID = null;
        HttpCookie cook = Request.Cookies["UserInfo"];
        if (cook != null)
        {
            userID = cook.Values["UserID"];
            sqlCon = new SqlConnection(strConn);
            sqlCon.Open();
            strSql = "select user_name from [user] where user_id = '" + userID + "'";
            sqlCmd = new SqlCommand(strSql, sqlCon);
            sqlReader = sqlCmd.ExecuteReader();
            if (sqlReader.Read())
            {
                LinkButton1.Text = sqlReader["user_name"].ToString() + "，歡迎您";
                login = true;
            }
            else
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：無法連結資料庫')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }

            sqlCon.Close();
            sqlCmd.Cancel();
        }
        else
        {
            LinkButton1.Text = "登入後台";
            login = false;
        }
        Panel2.Visible = false;
        Panel1.Visible = true;

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        Panel1.Visible = false;
        GridView2.DataBind();
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if(login)
        {
            Response.Redirect("/admin.aspx");
        }
        else
        {
            Response.Redirect("/login.aspx");
        }
    }
}