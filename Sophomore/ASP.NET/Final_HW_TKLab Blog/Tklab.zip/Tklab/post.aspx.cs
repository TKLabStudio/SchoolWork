﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class post : System.Web.UI.Page
{

    string postCon = null;
    string postTitle = null;
    string postNowCon;
    private string postNowTitle = null;
    string strSql;
    
    SqlConnection sqlCon = new SqlConnection();
    SqlCommand sqlCmd = new SqlCommand();
    SqlDataReader sqlReader;

    string postID = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        string userID = null;
        HttpCookie cook = Request.Cookies["UserInfo"];
        if (cook != null)
        {
            userID = cook.Values["UserID"];
            sqlCon = new SqlConnection(strConn);
            sqlCon.Open();
            strSql = "select user_name from [user] where user_id = '" + userID + "'";
            sqlCmd = new SqlCommand(strSql, sqlCon);
            sqlReader = sqlCmd.ExecuteReader();
            if (sqlReader.Read())
            {
                Label5.Text = sqlReader["user_name"].ToString();
            }
            else
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：無法連結資料庫')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }

            sqlCon.Close();
            sqlCmd.Cancel();
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('錯誤：您尚未登入')</script><br>";
            this.Page.Controls.Add(myMsg1);
            Response.Redirect("/login.aspx");
        }

        //   postNowCon = TextBox2.Text;
        // postNowTitle = TextBox1.Text;
        //TextBox1.AutoPostBack = true;
        //TextBox2.AutoPostBack = true;
        //TextBox1.Attributes.Add("onkeyup", postTitle = TextBox1.Text);
        //TextBox2.Attributes.Add("onkeyup", postCon = TextBox2.Text);


        try
        {
            postID = Request.QueryString["PostID"];
        }
        catch
        {
            Label6.Text = "修改文章 ";
        }
            if ((postID == "" || postID == null)&& !Page.IsPostBack)
        {
            Label6.Text = "新增文章 ";
           TextBox2.Text = "請在此輸入文章內容";
           TextBox2.Attributes.Add("style", "font-size:16pt;color:#999999");//順便改變字的大小顏色
            TextBox2.Attributes.Add("onFocus", "this.value=''");//一點擊TextBox2後，裡面的字馬上被清空
        }
        else if (!Page.IsPostBack)
        {
            Label6.Text = "修改文章 ";
            //Response.Write("2");
            //string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

            sqlCon = new SqlConnection(strConn);
            sqlCon.Open();
            strSql = "select * from [posts] where post_id = '" + postID + "'";
            sqlCmd = new SqlCommand(strSql, sqlCon);
            sqlReader = sqlCmd.ExecuteReader();
            if (sqlReader.Read())
            {
                postTitle = sqlReader["post_title"].ToString();
                postCon = sqlReader["post_content"].ToString();
                //Response.Write(sqlReader["user_login"].ToString());
            } else if ((postTitle == null) || (postTitle == ""))
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：文章標題抓取錯誤')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }
            else if ((postCon == null) || (postCon == ""))
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：文章內容抓取錯誤')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }
            else
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：未知的錯誤')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }
            sqlCon.Close();
            sqlCmd.Cancel();
            //TextBox2.Attributes.Add("style", "font-size:16pt;color:#666666");//順便改變字的大小顏色

            TextBox1.Text = postTitle;
            TextBox2.Text = postCon;
        }else
        {
            postNowTitle = (string)ViewState["postNowTitle"]; // 把資料由 ViewState 讀出。  
            postNowCon = (string)ViewState["postNowTitle"]; // 把資料由 ViewState 讀出。  
            //Response.Write(postNowTitle);
        }
    }
    

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (int.Parse(DropDownList1.SelectedValue) == 1)
        {
            if (postID == "" || postID == null)
            {
                Response.Redirect("/admin.aspx");
            }
            else
            {
                string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

                sqlCon = new SqlConnection(strConn);
                sqlCon.Open();
                strSql = "delete  from posts where post_id = '" + postID + "'";
                //Response.Write(i);

                sqlCmd = new SqlCommand(strSql, sqlCon);
                //sqlCmd.ExecuteNonQuery();

                //sqlReader = sqlCmd.ExecuteReader();
                if (sqlCmd.ExecuteNonQuery() == 1)
                {
                    Literal myMsg2 = new Literal();
                    myMsg2.Text = "<script>alert('成功刪除文章')</script><br>";
                    this.Page.Controls.Add(myMsg2);
                    //Response.Write(sqlReader["post_title"].ToString());
                    Response.Redirect("/admin.aspx");
                }
                else
                {
                    Literal myMsg2 = new Literal();
                    myMsg2.Text = "<script>alert('刪除文章失敗')</script><br>";
                    this.Page.Controls.Add(myMsg2);
                }

                sqlCon.Close();
                sqlCmd.Cancel();
                
            }
        } else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('請選擇功能')</script><br>";
            this.Page.Controls.Add(myMsg1);
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        postNowTitle = TextBox1.Text; 
        postNowCon = TextBox2.Text;
        ViewState["postNowTitle"] = postNowTitle;  // 儲存資料到 ViewState。  
        ViewState["postNowCon"] = postNowCon;  // 儲存資料到 ViewState。  

        //HttpCookie cook = new HttpCookie("Post");
        //cook.Values["postTitle"] = HttpUtility.UrlEncode(TextBox1.Text);
        //cook.Values["postCon"] = HttpUtility.UrlEncode(TextBox2.Text);
        //Response.Cookies.Add(cook);

        //Label7.Text = postNowTitle;
        //Label8.Text = postNowCon;
        //Label5.Text = postNowTitle;


        if ((postNowTitle != "") || (postNowTitle != null) || (postNowCon != "") || (postNowCon != null))
            {
                string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

                sqlCon = new SqlConnection(strConn);
                sqlCon.Open();
            if (postID == "" || postID == null)
            {
                strSql = "INSERT INTO [posts] ([post_title] ,[post_content] ,[post_author]) values ('" + postNowTitle + "','" + postNowCon + "' ,'4')";
            }
            else
            {
                strSql = "UPDATE [posts] SET [post_title] = '" + postNowTitle + "' ,[post_content] = '" + postNowCon + "',[post_author] = '4' WHERE post_id = '"+postID+"'";
            }
            sqlCmd = new SqlCommand(strSql, sqlCon);
                sqlCmd.ExecuteNonQuery();
                sqlCmd.Cancel();
                //sqlReader = sqlCmd.ExecuteReader();
                if (sqlCmd.ExecuteNonQuery() == 1)
                {
                //Label5.Text = "成功新增/修改文章";
                
                    Literal myMsg1 = new Literal();
                    myMsg1.Text = "<script>alert('成功新增/修改文章')</script><br>";
                    this.Page.Controls.Add(myMsg1);
                    
                }
                else
                {
                    Literal myMsg1 = new Literal();
                    myMsg1.Text = "<script>alert('新增/修改文章失敗')</script><br>";
                    this.Page.Controls.Add(myMsg1);
                }
                sqlCon.Close();
                sqlCmd.Cancel();
            }
            else if ((postNowTitle == "") || (postNowTitle == null))
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：請輸入文章標題')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }
            else if ((postNowCon == "") || (postNowCon == null))
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：請輸入文章內容')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }
            else
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：未知的錯誤')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }

    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        //TextBox1.AutoPostBack = true;
        //postNowTitle = TextBox1.Text;
        //postNowCon = TextBox2.Text;
    }

    protected void Button6_Click(object sender, EventArgs e)
    {
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        //TextBox2.AutoPostBack = true;
        //postNowTitle = TextBox1.Text;
        //postNowCon = TextBox2.Text;
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("/admin.aspx");
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("/user.aspx");

    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        HttpCookie cook = Request.Cookies["UserInfo"];
        cook.Expires = DateTime.Now.AddDays(-1d);//設定cookie的到期日為已過期　
        Response.Cookies.Add(cook);//將cookie變動寫回client端
        Response.Redirect("/login.aspx");
    }

    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("/index.aspx");

    }
}