﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class _login : System.Web.UI.Page
{
    string strSql;
    SqlConnection sqlCon = new SqlConnection();
    SqlCommand sqlCmd = new SqlCommand();
    SqlDataReader sqlReader;
    string user = null; string pass = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Text = null;
        string userText = TextBox1.Text;
        string passText = TextBox2.Text;

        string strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        sqlCon = new SqlConnection(strConn);
        sqlCon.Open();
        strSql = "select * from [user] where user_login = '" + userText+"'";
        sqlCmd = new SqlCommand(strSql, sqlCon);
        sqlReader = sqlCmd.ExecuteReader();
        if (sqlReader.Read())
        {
            user = sqlReader["user_login"].ToString();
            pass = sqlReader["user_pass"].ToString();
            //Response.Write(sqlReader["user_login"].ToString());
        }
        else
        {
            Literal myMsg1 = new Literal();
            myMsg1.Text = "<script>alert('錯誤：無法連結資料庫')</script><br>";
            this.Page.Controls.Add(myMsg1);
        }

        sqlCon.Close();
        sqlCmd.Cancel();


        if ((user == null) || (user == "") || (userText != user))
        {
            Label1.Text = "錯誤：您輸入給使用者名稱" + user + " 的密碼不正確。 忘記密碼？";
        }else if (passText != pass)
        {
            Label1.Text = "錯誤：無效的使用者名稱。 忘記密碼？";
        }
        else if ((passText == pass) && (userText == user))
        {
            string userID = null;
            sqlCon.Open();
            strSql = "select user_id from [user] where user_login = '" + userText + "'";
            sqlCmd = new SqlCommand(strSql, sqlCon);
            sqlReader = sqlCmd.ExecuteReader();
            if (sqlReader.Read())
            {
                userID = sqlReader["user_id"].ToString();
                //Response.Write(sqlReader["user_login"].ToString());
            }
            else
            {
                Literal myMsg1 = new Literal();
                myMsg1.Text = "<script>alert('錯誤：無法連結資料庫')</script><br>";
                this.Page.Controls.Add(myMsg1);
            }


            HttpCookie cook = new HttpCookie("UserInfo");
            cook.Values["UserID"] = HttpUtility.UrlEncode(userID);
            cook.Expires = DateTime.Now.AddDays(7);
            Response.Cookies.Add(cook);
            Response.Redirect("/admin.aspx");
        }
        else
        {
            Label1.Text = "錯誤：未知的錯誤";
        }
        sqlCon.Close();
        sqlCmd.Cancel();
    }
}